<?php


//constante 
date_default_timezone_set("America/Guatemala");
const SERVERURL="http://localhost/warehouse_asisstant/";
//const SERVERURL="https://url.com/";



?>