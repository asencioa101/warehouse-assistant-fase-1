<?php

setlocale(LC_ALL, "es_ES");

// Variables de inicio
$modulo = "Proveedores";
$nav = '2'; // Cambia este valor según tu navegación

require_once "../controller/assets/svrurl.php";
require_once "../controller/assets/validacion.php";
require_once "../controller/assets/inicio.php";

// Validación de login
$login = new seguridad;
$login->seguridadLogin();

require "../controller/assets/session.php";

// Conectar a la base de datos y obtener la información de los proveedores
require_once "../controller/db/conexion.php";

$conect = new basedatos;
$conexion = $conect->conectarBD();

// Consulta para obtener proveedores
$query = "SELECT * FROM proveedores";
$result = mysqli_query($conexion, $query);

$proveedores = [];
if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $proveedores[] = $row;
    }
}

// Cierra la conexión
mysqli_close($conexion);

?>

<?php
// Requerir NAVMENU 
require "../controller/assets/menunav.php";
?>

<!-- Proveedores -->
<div id="bodysecon" class="row">
    <h1>
        <center>Proveedores</center>
    </h1>
    <div class="row container">
        <button class="btn" id="btnAgregarProveedor">Agregar Nuevo Proveedor</button>
        <table class="striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Dirección</th>
                    <th>Teléfono</th>
                    <th>Email</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($proveedores)): ?>
                    <?php foreach ($proveedores as $proveedor): ?>
                        <tr>
                            <td><?php echo $proveedor['id_proveedor']; ?></td>
                            <td><?php echo $proveedor['nombre']; ?></td>
                            <td><?php echo $proveedor['direccion']; ?></td>
                            <td><?php echo $proveedor['telefono']; ?></td>
                            <td><?php echo $proveedor['email']; ?></td>
                            <td>
                                <a href="#" class="btn editar" data-id="<?php echo $proveedor['id_proveedor']; ?>">Editar</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6">No hay proveedores registrados.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<!-- Fin Proveedores -->

<!-- SCRIPTS CARGA -->
<?php
require_once "../controller/assets/scripts.php";
?>
<!-- SCRIPTS CARGA -->

<!-- SCRIPTS -->
<script>
    $(document).ready(function() {
        // Inicializar la tabla
        $('table').dataTable();

        // Evento para abrir el modal al hacer clic en "Agregar Nuevo Proveedor"
        $('#btnAgregarProveedor').on('click', function() {
            $('#modalAgregarProveedor').modal('open');
            $('#AgregarProveedor').trigger("reset"); // Limpiar el formulario
        });

        // Evento de clic en el botón de editar
        $('.editar').on('click', function(e) {
            e.preventDefault();
            var id_proveedor = $(this).data('id');

            // Cargar los datos del proveedor en el formulario modal
            $.ajax({
                url: '../controller/db/editar_proveedor.php',
                type: 'POST',
                dataType: 'json',
                data: { id_proveedor: id_proveedor },
                success: function(data) {
                    if (!data.error) {
                        $('#template_nombre_editar').val(data.nombre);
                        $('#template_direccion_editar').val(data.direccion);
                        $('#template_telefono_editar').val(data.telefono);
                        $('#template_email_editar').val(data.email);
                        $('#id_proveedor_editar').val(data.id_proveedor);

                        // Abrir el modal para editar
                        $('#modalEditarProveedor').modal('open');
                    } else {
                        swal("Error", "No se pudo cargar el proveedor.", "error");
                    }
                },
                error: function() {
                    swal("Error", "Hubo un problema al cargar los datos.", "error");
                }
            });
        });

        // Enviar el formulario para agregar proveedor
        $('#AgregarProveedor').on('submit', function(e) {
            e.preventDefault();
            var formData = $(this).serialize();

            $.ajax({
                url: '../controller/db/agregar_proveedor.php', // Archivo que guarda o actualiza el proveedor
                type: 'POST',
                data: formData,
                success: function(response) {
                    if (response.success) {
                        swal("Éxito", "Proveedor agregado correctamente.", "success")
                            .then(() => location.reload());
                    } else {
                        swal("Error", "Hubo un problema al agregar el proveedor.", "error");
                    }
                },
                error: function() {
                    swal("Error", "Hubo un problema al procesar la solicitud.", "error");
                }
            });
        });

        // Enviar el formulario para editar proveedor
        $('#EditarProveedor').on('submit', function(e) {
            e.preventDefault();
            var formData = $(this).serialize();

            $.ajax({
                url: '../controller/db/actualizar_proveedor.php', // Script para guardar la edición
                type: 'POST',
                data: formData,
                success: function(response) {
                    if (response.success) {
                        swal("Éxito", "Proveedor actualizado correctamente.", "success")
                            .then(() => location.reload());
                    } else {
                        swal("Error", response.message || "No se pudo actualizar el proveedor.", "error");
                    }
                },
                error: function() {
                    swal("Error", "Hubo un problema al actualizar el proveedor.", "error");
                }
            });
        });
    });
</script>
<!-- SCRIPTS  -->

<!-- Modal para agregar proveedor -->
<div id="modalAgregarProveedor" class="modal">
    <div class="modal-content">
        <h4>Agregar Proveedor</h4>
        <form id="AgregarProveedor">
            <div class="input-field col s12">
                <input placeholder="Ingrese el nombre" id="template_nombre" name="template_nombre" type="text" required>
                <label for="template_nombre">Nombre</label>
            </div>
            <div class="input-field col s12">
                <input placeholder="Ingrese la dirección" id="template_direccion" name="template_direccion" type="text" required>
                <label for="template_direccion">Dirección</label>
            </div>
            <div class="input-field col s12">
                <input placeholder="Ingrese el teléfono" id="template_telefono" name="template_telefono" type="text" required>
                <label for="template_telefono">Teléfono</label>
            </div>
            <div class="input-field col s12">
                <input placeholder="Ingrese el email" id="template_email" name="template_email" type="email" required>
                <label for="template_email">Email</label>
            </div>
            <div class="row">
                <button type="submit" class="btn">Guardar Proveedor</button>
            </div>
        </form>
    </div>
</div>

<!-- Modal para editar proveedor -->
<div id="modalEditarProveedor" class="modal">
    <div class="modal-content">
        <h4>Editar Proveedor</h4>
        <form id="EditarProveedor">
            <div class="input-field col s12">
                <input placeholder="Ingrese el nombre" id="template_nombre_editar" name="template_nombre" type="text" required>
                <label for="template_nombre_editar">Nombre</label>
            </div>
            <div class="input-field col s12">
                <input placeholder="Ingrese la dirección" id="template_direccion_editar" name="template_direccion" type="text" required>
                <label for="template_direccion_editar">Dirección</label>
            </div>
            <div class="input-field col s12">
                <input placeholder="Ingrese el teléfono" id="template_telefono_editar" name="template_telefono" type="text" required>
                <label for="template_telefono_editar">Teléfono</label>
            </div>
            <div class="input-field col s12">
                <input placeholder="Ingrese el email" id="template_email_editar" name="template_email" type="email" required>
                <label for="template_email_editar">Email</label>
            </div>
            <input type="hidden" id="id_proveedor_editar" name="id_proveedor">
            <div class="row">
                <button type="submit" class="btn">Guardar Cambios</button>
            </div>
        </form>
    </div>
</div>



<!-- Fin HTML -->
<?php
require_once "../controller/assets/fin.php";
?>

<script>
    $(document).ready(function() {
        // Inicializar los modales
        $('.modal').modal();
    });
</script>
