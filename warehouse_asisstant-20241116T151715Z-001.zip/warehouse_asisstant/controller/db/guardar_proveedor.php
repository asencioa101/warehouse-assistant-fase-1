<?php
require_once "../db/conexion.php";

$conect = new basedatos;
$conexion = $conect->conectarBD();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_proveedor = $_POST['id_proveedor'] ?? null;
    $nombre = $_POST['template_nombre'];
    $direccion = $_POST['template_direccion'];
    $telefono = $_POST['template_telefono'];
    $email = $_POST['template_email'];

    if ($id_proveedor) {
        $query = "UPDATE proveedores SET nombre = ?, direccion = ?, telefono = ?, email = ? WHERE id_proveedor = ?";
        $stmt = $conexion->prepare($query);
        $stmt->bind_param("ssssi", $nombre, $direccion, $telefono, $email, $id_proveedor);
    } else {
        $query = "INSERT INTO proveedores (nombre, direccion, telefono, email) VALUES (?, ?, ?, ?)";
        $stmt = $conexion->prepare($query);
        $stmt->bind_param("ssss", $nombre, $direccion, $telefono, $email);
    }

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => $id_proveedor ? 'Proveedor actualizado correctamente.' : 'Proveedor agregado correctamente.']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error al guardar proveedor: ' . $stmt->error]);
    }

    $stmt->close();
}
mysqli_close($conexion);
?>
