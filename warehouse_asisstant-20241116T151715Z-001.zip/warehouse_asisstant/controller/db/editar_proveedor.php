<?php
// Requerir conexión a la base de datos
require_once "../db/conexion.php";

// Verificar si se ha enviado el ID del proveedor
if (isset($_POST['id_proveedor'])) {
    $id_proveedor = intval($_POST['id_proveedor']); // Asegurarse de que el ID sea un número

    // Conectar a la base de datos
    $conect = new basedatos;
    $conexion = $conect->conectarBD();

    // Consulta para obtener el proveedor
    $query = "SELECT * FROM proveedores WHERE id_proveedor = ?";
    $stmt = $conexion->prepare($query);
    $stmt->bind_param("i", $id_proveedor); // Vincular el ID del proveedor

    if ($stmt->execute()) {
        $result = $stmt->get_result();
        $proveedor = $result->fetch_assoc();

        if ($proveedor) {
            // Devolver datos en formato JSON
            echo json_encode($proveedor);
        } else {
            echo json_encode(['error' => true, 'message' => 'Proveedor no encontrado.']);
        }
    } else {
        echo json_encode(['error' => true, 'message' => 'Error en la consulta.']);
    }

    // Cerrar conexión
    $stmt->close();
    mysqli_close($conexion);
} else {
    echo json_encode(['error' => true, 'message' => 'ID de proveedor no proporcionado.']);
}
?>


