<?php

setlocale(LC_ALL, "es_ES");

$modulo = "Ingresos";
$nav = '3';

require_once "../controller/assets/svrurl.php";
require_once "../controller/assets/validacion.php";
require_once "../controller/assets/inicio.php";

// Validación de login
$login = new seguridad;
$login->seguridadLogin();

require "../controller/assets/session.php";

// Conectar a la base de datos
require_once "../controller/db/conexion.php";
$conect = new basedatos;
$conexion = $conect->conectarBD();

// Consulta para obtener los ingresos existentes
$queryIngresos = "SELECT * FROM ingresos";
$resultIngresos = mysqli_query($conexion, $queryIngresos);

$ingresos = [];
if ($resultIngresos) {
    while ($row = mysqli_fetch_assoc($resultIngresos)) {
        $ingresos[] = $row;
    }
}

// Cierra la conexión
mysqli_close($conexion);

?>

<?php
// Requerir NAVMENU
require "../controller/assets/menunav.php";
?>

<!-- Encabezado de Ingresos -->
<div id="bodysecon" class="row">
    <h1><center>Ingresos</center></h1>
    <div class="row container">
        <!-- Botón para agregar ingreso -->
        <button class="btn" id="btnAgregarIngreso">Registrar Nuevo Ingreso</button>
        
        <table class="striped">
            <thead>
                <tr>
                    <th>ID Ingreso</th>
                    <th>Fecha</th>
                    <th>Proveedor</th>
                    <th>Total</th>
                    <th>Comentario</th>
                    <th>Usuario</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($ingresos)): ?>
                    <?php foreach ($ingresos as $ingreso): ?>
                        <tr>
                            <td><?php echo $ingreso['id_ingreso']; ?></td>
                            <td><?php echo $ingreso['fecha_ingreso']; ?></td>
                            <td><?php echo $ingreso['id_proveedor']; ?></td>
                            <td><?php echo $ingreso['total']; ?></td>
                            <td><?php echo $ingreso['comentario']; ?></td>
                            <td><?php echo $ingreso['username']; ?></td>
                            <td>
                                <a href="#" class="btn verDetalles" data-id="<?php echo $ingreso['id_ingreso']; ?>">Ver Detalles</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7">No hay ingresos registrados.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<!-- Fin Encabezado de Ingresos -->

<!-- SCRIPTS CARGA -->
<?php
require_once "../controller/assets/scripts.php";
?>
<!-- SCRIPTS CARGA -->

<!-- SCRIPTS -->
<script>
    $(document).ready(function() {
        // Inicializar la tabla
        $('table').dataTable();

        // Evento para abrir el modal de nuevo ingreso
        $('#btnAgregarIngreso').on('click', function() {
            $('#modalAgregarIngreso').modal('open'); // Abre el modal
            $('#AgregarIngreso').trigger("reset"); // Limpiar el formulario
        });

        // Enviar el formulario para agregar nuevo ingreso
        $('#AgregarIngreso').on('submit', function(e) {
            e.preventDefault();
            var formData = $(this).serialize();

            $.ajax({
                url: '../controller/db/agregar_ingreso.php',
                type: 'POST',
                data: formData,
                success: function(response) {
                    if (response.success) {
                        swal("Éxito", "Ingreso registrado correctamente.", "success")
                            .then(() => location.reload());
                    } else {
                        swal("Error", "Hubo un problema al registrar el ingreso.", "error");
                    }
                },
                error: function() {
                    swal("Error", "Hubo un problema al procesar la solicitud.", "error");
                }
            });
        });

        // Evento para ver detalles del ingreso
        $('.verDetalles').on('click', function(e) {
            e.preventDefault();
            var id_ingreso = $(this).data('id');

            // Cargar el modal para agregar productos al detalle
            $('#modalDetallesIngreso').modal('open');
            $('#id_ingreso_detalle').val(id_ingreso);
        });

        // Enviar el formulario para agregar detalles al ingreso
        $('#AgregarDetalleIngreso').on('submit', function(e) {
            e.preventDefault();
            var formData = $(this).serialize();

            $.ajax({
                url: '../controller/db/agregar_detalle_ingreso.php',
                type: 'POST',
                data: formData,
                success: function(response) {
                    if (response.success) {
                        swal("Éxito", "Producto agregado al ingreso.", "success")
                            .then(() => location.reload());
                    } else {
                        swal("Error", "Hubo un problema al agregar el producto.", "error");
                    }
                },
                error: function() {
                    swal("Error", "Hubo un problema al procesar la solicitud.", "error");
                }
            });
        });
    });
</script>
<!-- SCRIPTS  -->

<!-- Modal para agregar ingreso -->
<div id="modalAgregarIngreso" class="modal">
    <div class="modal-content">
        <h4>Registrar Nuevo Ingreso</h4>
        <form id="AgregarIngreso">
            <div class="input-field col s12">
                <input id="id_proveedor" name="id_proveedor" type="text" required>
                <label for="id_proveedor">ID Proveedor</label>
            </div>
            <div class="input-field col s12">
                <input id="fecha_ingreso" name="fecha_ingreso" type="date" required>
                <label for="fecha_ingreso">Fecha de Ingreso</label>
            </div>
            <div class="input-field col s12">
                <input id="total" name="total" type="number" required>
                <label for="total">Total</label>
            </div>
            <div class="input-field col s12">
                <textarea id="comentario" name="comentario" class="materialize-textarea"></textarea>
                <label for="comentario">Comentario</label>
            </div>
            <div class="row">
                <button type="submit" class="btn">Guardar Ingreso</button>
            </div>
        </form>
    </div>
</div>

<!-- Modal para agregar productos al detalle del ingreso -->
<div id="modalDetallesIngreso" class="modal">
    <div class="modal-content">
        <h4>Agregar Producto al Ingreso</h4>
        <form id="AgregarDetalleIngreso">
            <input type="hidden" id="id_ingreso_detalle" name="id_ingreso">
            <div class="input-field col s12">
                <input id="id_producto" name="id_producto" type="text" required>
                <label for="id_producto">ID Producto</label>
            </div>
            <div class="input-field col s12">
                <input id="cantidad" name="cantidad" type="number" required>
                <label for="cantidad">Cantidad</label>
            </div>
            <div class="input-field col s12">
                <input id="precio_unitario" name="precio_unitario" type="number" step="0.01" required>
                <label for="precio_unitario">Precio Unitario</label>
            </div>
            <div class="input-field col s12">
                <input id="id_bodega" name="id_bodega" type="text" required>
                <label for="id_bodega">ID Bodega</label>
            </div>
            <div class="input-field col s12">
                <input id="id_ubicacion" name="id_ubicacion" type="text" required>
                <label for="id_ubicacion">ID Ubicación</label>
            </div>
            <div class="row">
                <button type="submit" class="btn">Agregar Producto</button>
            </div>
        </form>
    </div>
</div>

<?php
require_once "../controller/assets/fin.php";
?>
