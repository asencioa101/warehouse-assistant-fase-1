<?php
// Requerir conexión a la base de datos
require_once "../db/conexion.php";

// Verificar si se han enviado los datos del proveedor
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Obtener los datos del formulario
    $nombre = trim($_POST['template_nombre']);
    $direccion = trim($_POST['template_direccion']);
    $telefono = trim($_POST['template_telefono']);
    $email = trim($_POST['template_email']);

    // Validar los datos (puedes añadir más validaciones según sea necesario)
    if (empty($nombre) || empty($direccion) || empty($telefono) || empty($email)) {
        echo json_encode(['success' => false, 'message' => 'Todos los campos son obligatorios.']);
        exit;
    }

    // Conectar a la base de datos
    $conect = new basedatos;
    $conexion = $conect->conectarBD();

    // Consulta para insertar el nuevo proveedor
    $query = "INSERT INTO proveedores (nombre, direccion, telefono, email) VALUES (?, ?, ?, ?)";
    $stmt = $conexion->prepare($query);
    $stmt->bind_param("ssss", $nombre, $direccion, $telefono, $email); // Vincular los parámetros

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Proveedor agregado correctamente.']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error al agregar el proveedor.']);
    }

    // Cerrar la conexión
    $stmt->close();
    mysqli_close($conexion);
} else {
    echo json_encode(['success' => false, 'message' => 'Método no permitido.']);
}
?>


