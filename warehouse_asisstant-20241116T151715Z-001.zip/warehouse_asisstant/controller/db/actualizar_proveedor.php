<?php
require_once "../db/conexion.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_proveedor = $_POST['id_proveedor'];
    $nombre = $_POST['template_nombre'];
    $direccion = $_POST['template_direccion'];
    $telefono = $_POST['template_telefono'];
    $email = $_POST['template_email'];

    $conect = new basedatos;
    $conexion = $conect->conectarBD();

    // Consulta para actualizar el proveedor
    $query = "UPDATE proveedores SET nombre = ?, direccion = ?, telefono = ?, email = ? WHERE id_proveedor = ?";
    $stmt = $conexion->prepare($query);
    $stmt->bind_param("ssssi", $nombre, $direccion, $telefono, $email, $id_proveedor);

    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error al actualizar el proveedor.']);
    }

    $stmt->close();
    mysqli_close($conexion);
}
?>

