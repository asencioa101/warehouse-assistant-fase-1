<!--Menu Admin-->
<!-- Dropdown Structure -->
<ul id="menuadmin" class="dropdown-content">
  <li><a href="./settings.php" class="black-text"><i class="material-icons black-text">build</i>Configuracion</a></li>
  <li class="divider"></li>
  <li><a href="../controller/assets/salir.php" class="black-text"><i class="material-icons black-text">exit_to_app</i>Salir</a></li>
</ul>
<!--Menu Admin-->
<!-- Dropdown Structure -->

 <a id="nivelUser" class="hide"><?php echo $template_tipo; ?></a>

<!-- NAV -->
<ul id="slide-out" class="sidenav sidenav-fixed">
  <li style="height: auto;">
    <div class="user-view" style="width: 100%;">
      <div class="row center">
        <div class="col s12">
         <i class="material-icons large accentfP">inventory</i>
        </div>
      </div>
    </div>
  </li>
  <li>
    <div class="user-view" style="padding: 0px 32px 0;">
      <a><span class="black-text email"><strong><?php echo $template_email; ?></strong></span></a>
    </div>
  </li>
  <li><a class="subheader">Menu</a></li>

  <!-- opcione de incio en menu nav  constado izquierdo-->
  <li><a id="n1" href="./"><i id="i1" class="material-icons">home</i>Inicio</a></li>
  <li><a id="n2" href="./proveedores.php"><i i="i2" class="material-icons">factory</i>Proveedores</a></li>
  <li><a id="n3" href="./ingresos.php"><i id="i3" class="material-icons">add_box</i>Ingreso</a></li>
  <li><a id="n5" href="./productos.php"><i id="i5" class="material-icons">pallets</i>Productos</a></li>
  <li><a id="n6" href="./salidas.php"><i id="i6" class="material-icons">indeterminate_check_box</i>Salidas</a></li>
  <li><a id="n7" href="./clientes.php"><i id="i7" class="material-icons">account_box</i>Clientes</a></li>
  <!-- Opciones usuarios   -->
  <li>
    <a id="n9" href="./usuario.php">
      <!-- icono -->
      <i id="i9" class="material-icons">face</i>
      <!-- icono -->
      Usuarios
    </a>
  </li>
  <!-- Opciones de salir del programa  -->
  <li><a id="n4" href="../controller/assets/salir.php"><i id="i4" class="material-icons">exit_to_app</i>Salir</a>

</ul>
<!-- NAV -->

<script type="text/javascript" charset="utf-8" async>
  let tipoUserV = $("#nivelUser").text();

    console.info("Bienvenido a la cosola", tipoUserV);
</script>


<!-- NAV PRINCIPAL superior-->
<nav class=" borde7 hoverable" style="width: 97% !important; margin-left: 1.5%; margin-top: 1%; margin-bottom: 25px;">
  <div class="nav-wrapper" style="margin: 25px;">
    <a class="brand-logo" href="#"><i id="ocultarnav" class="material-icons hide-on-med-and-down">fullscreen</i><?php echo (new DateTime())->format('l d \d\e F \d\e\l Y'); ?></a>
    <a href="#" data-target="slide-out" class="sidenav-trigger"><i class="material-icons">menu</i></a>
    <ul class="right hide-on-med-and-down">
        <li><a class="busquedaglobal"><i class="material-icons left">search</i></a></li>
        <li><a id="zonaBienvenido" class="truncate">Bienvenido</a></li>
        <li><a id="dropdownuser" class="dropdown-trigger" data-target="menuadmin"><i class="material-icons left white-text">face</i><?php echo $template_nombre; ?><i class="material-icons right">arrow_drop_down</i></a></li>
    </ul>
  </div>
</nav>
<!-- NAV PRINCIPAL superior-->




<script type="text/javascript" charset="utf-8">
  $("#zonaBienvenido").text("Bienvenido");

  var menunavID = <?php echo $nav ?>;
  if (menunavID == "0") {
    $("#n" + menunavID + "").addClass('animated fadeOut');
    setTimeout(function() {
      $("#n" + menunavID + "").addClass('hide');
    }, 500);
  } else {
    $("#n" + menunavID + "").addClass('fontP');
    $("#i" + menunavID + "").addClass('accentfP');
  }

  $("#ocultarnav").click(function(event) {
    event.preventDefault();
    if ($("#slide-out").hasClass('sidenav-fixed')) {
      $("#ocultarnav").text('fullscreen');
      $("#slide-out").removeClass('sidenav-fixed');
      $("#bodyprin").removeClass('responsivo');
      $('.sidenav').sidenav("close");
      actResponsive();
    } else {
      $("#slide-out").addClass('sidenav-fixed');
      $("#bodyprin").addClass('responsivo');
      $('.sidenav').sidenav("open");
      $("#ocultarnav").text('fullscreen_exit');
      actResponsive();
    }
  });
</script>