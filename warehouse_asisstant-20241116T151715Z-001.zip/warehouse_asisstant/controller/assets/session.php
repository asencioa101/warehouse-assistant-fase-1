  <?php
        $template_id = $_SESSION['template_id'];
        $template_nombre = $_SESSION['template_nombre'];                    
        $template_email = $_SESSION['template_email'];
        $template_tipo = $_SESSION['template_tipo'];
        $template_acceso = $_SESSION['template_acceso'];
?>


