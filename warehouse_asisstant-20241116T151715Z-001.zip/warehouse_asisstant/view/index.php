  <?php

  setlocale(LC_ALL, "es_ES");
  $modulo = "Formulario";
  $nav = '0';

  require_once "../controller/assets/svrurl.php";
  require_once "../controller/assets/validacion.php";
  require_once "../controller/assets/inicio.php";

  // Validación de login
  $login = new seguridad;
  $login->seguridadLogin();

  require_once "../controller/assets/session.php";

  ?>
  <!-- Usuario -->
  <a id="tipodeusuario" class="hide"><?php echo $template_tipo ?></a>
  <!-- Usuario -->
  <?php
  // Requerir NAVMENU
  require "../controller/assets/menunav.php";
  ?>

  <!-- BODDY -->
  <div id="bodysecon" class="row">
    <div class="row container">
      <div class="col s12">
        <h1>Bienvenido de nuevo</h1>
        <div id="chart"></div>
      </div>
    </div>

    <!-- Botón flotante de acceso al chatbot -->
    <div id="chatbot-icon" class="chatbot-icon" onclick="toggleChatbot()">
    <i class="material-icons">forum smart_toy</i> <!-- O usa FontAwesome: <i class="fas fa-comments"></i> -->
  </div>

    <!-- Contenedor del Chatbot flotante -->
    <div id="chatbot-container" class="chatbot-container hide">
      <div class="card-panel">
        <div class="wrapper">
          <div class="title center-align">Assistant</div>
          <div class="form chat-window" style="max-height: 400px; overflow-y: auto;">
            <div class="bot-inbox inbox">
              <div class="msg-header bot-message">
                <p>"¡Hola! Bienvenido al chat. Puedes dejar aquí tus preguntas y sugerencias, y estaré encantado de ayudarte."</p>
              </div>
            </div>
          </div>
          <div class="typing-field">
            <div class="input-data">
              <input id="data" type="text" placeholder="Escribe algo aquí..." required>
              <button id="send-btn" class="btn #00796b">Enviar</button>
            </div>
          </div>
        </div>
      </div>
    </div>

  </div>
  <!--Datos-->
  <!-- BODDY -->

  <!-- SCRIPTS CARGA -->
  <?php
  require_once "../controller/assets/scripts.php";
  ?>
  <!-- SCRIPTS CARGA -->

  <!-- SCRIPTS -->
  <script src="https://kit.fontawesome.com/a076d05399.js"></script>
  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <script>
    function toggleChatbot() {
      const chatbotContainer = document.getElementById("chatbot-container");
      chatbotContainer.classList.toggle("hide");
    }

    $(document).ready(function() {
      $("#send-btn").on("click", function() {
        const value = $("#data").val();
        if (!value.trim()) return;  // Evita enviar mensajes vacíos

        // Añade el mensaje del usuario
        const userMessage = '<div class="user-inbox inbox"><div class="msg-header user-message"><p>' + value + '</p></div></div>';
        $(".form").append(userMessage);
        $("#data").val('');

        // Inicia la petición AJAX
        $.ajax({
          url: 'message.php',
          type: 'POST',
          data: { text: value },
          success: function(result) {
            const botReply = '<div class="bot-inbox inbox"><div class="icon"><i class="fas fa-user"></i></div><div class="msg-header bot-message"><p>' + result + '</p></div></div>';
            $(".form").append(botReply);
            $(".form").scrollTop($(".form")[0].scrollHeight);  // Desplazarse automáticamente hacia abajo
          }
        });
      });
    });
  </script>
  <!-- SCRIPTS -->

  <!-- Estilos -->
  <style>
    /* Estilos para el icono de chatbot */
    .chatbot-icon {
      position: fixed;
      bottom: 20px;
      right: 20px;
      background-color: #00796b;
      color: #fff;
      font-size: 24px;
      border-radius: 50%;
      padding: 15px;
      cursor: pointer;
      z-index: 1000;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }

    /* Estilos del contenedor del chatbot */
    .chatbot-container {
      position: fixed;
      bottom: 80px;
      right: 20px;
      max-width: 350px;
      width: 100%;
      border-radius: 8px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
      z-index: 1000;
      background: #fff;
    }

    /* Ocultar contenedor del chatbot por defecto */
    .hide {
      display: none;
    }

    /* Estilos de los mensajes */
    .chat-window {
      background: #00796b;
      border-radius: 8px;
      padding: 10px;
    }

    .inbox {
      display: flex;
      margin-bottom: 10px;
    }

    .user-inbox {
      justify-content: flex-end;
    }

    .bot-inbox {
      justify-content: flex-start;
    }

    .msg-header {
      max-width: 70%;
      padding: 8px 12px;
      border-radius: 8px;
      font-size: 14px;
    }

    .user-message {
      background-color: #c1e3ff;
      color: #000;
      border-radius: 8px 0 8px 8px;
    }

    .bot-message {
      background-color: #f0f0f0;
      color: #333;
      border-radius: 0 8px 8px 8px;
    }
  </style>
  <!-- Fin HTML -->
  <?php
  require_once "../controller/assets/fin.php";
  ?>

