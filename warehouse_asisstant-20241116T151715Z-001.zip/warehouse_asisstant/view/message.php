<?php
// Conexión a la base de datos
$conn = mysqli_connect("localhost", "root", "", "chatbot") or die("Database Error");

// Obtener el mensaje del usuario a través de AJAX
$getMesg = mysqli_real_escape_string($conn, $_POST['text']);

// Comprobar si la pregunta existe en la tabla chatbot
$check_data = "SELECT replies FROM chatbot WHERE queries LIKE '%$getMesg%'";
$run_query = mysqli_query($conn, $check_data) or die("Error");

// Si la consulta del usuario coincide con una en la tabla, mostramos la respuesta
if (mysqli_num_rows($run_query) > 0) {
    $fetch_data = mysqli_fetch_assoc($run_query);
    $reply = $fetch_data['replies'];
    echo $reply;
} else {
    // Insertar la pregunta no resuelta en la tabla mensajes_no_resueltos
    $insert_query = "INSERT INTO mensajes_no_resueltos (mensaje) VALUES ('$getMesg')";
    if (mysqli_query($conn, $insert_query)) {
        // Respuesta al usuario informando que el mensaje fue enviado al administrador
        echo "Gracias por tu mensaje. Fue enviado al administrador para su revisión.";
    } else {
        echo "Hubo un error al procesar tu mensaje. Por favor intenta de nuevo más tarde.";
    }
}

// Cerrar la conexión
mysqli_close($conn);
?>
