-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 09-11-2024 a las 05:43:18
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `chatbot`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `chatbot`
--

CREATE TABLE `chatbot` (
  `id` int(11) NOT NULL,
  `queries` varchar(300) NOT NULL,
  `replies` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `chatbot`
--

INSERT INTO `chatbot` (`id`, `queries`, `replies`) VALUES
(1, 'Hola me podrías ayudar? Tengo una consulta', 'Claro estoy para servirte en lo que requieras'),
(2, 'No tengo acceso a Internet', 'Vale te pregunto, donde te encuentras ahora, ¿hay más dispositivos conectados a tu red local?'),
(3, 'Si claro tengo dos teléfonos, pero ninguno tiene acceso a Internet tampoco', 'Tienes algún ordenador conectado por cable'),
(4, 'Si, claro, requieres que lo encienda?', 'Si por favor y me confirmas si no tienes acceso a Internet, en tu ordenador cuando encienda'),
(5, 'Te confirmo que tampoco tiene Internet', 'Reinicia tu modem, espera 10 minutos y reintenta, me confirmas'),
(6, 'Ya me funciona el Internet, muchas gracias', 'Excelente me alegro mucho, gracias por comunicarte con Soporte Técnico ChatBot ConfiguroWeb'),
(7, '¿Cómo ingreso un nuevo producto?', 'Para ingresar un nuevo producto, dirígete a la sección de \"Productos\" en el menú y selecciona \"Agregar nuevo producto\". Completa el formulario y guarda.'),
(8, '¿Cómo elimino un producto?', 'Para eliminar un producto, busca el producto en la lista, selecciona la opción \"Eliminar\" y confirma la acción.'),
(9, '¿Cómo actualizo la cantidad de un producto?', 'Para actualizar la cantidad, ve a \"Inventario\", selecciona el producto y usa la opción \"Actualizar cantidad\".'),
(10, '¿Cómo registro una entrada de inventario?', 'Ve a \"Movimientos\" en el menú, selecciona \"Registrar entrada\" e ingresa los datos del nuevo stock que entró al almacén.'),
(11, '¿Cómo registro una salida de inventario?', 'En \"Movimientos\", selecciona \"Registrar salida\", luego elige el producto, cantidad y confirma el registro.'),
(12, '¿Puedo generar reportes?', 'Sí, en la sección de \"Reportes\" puedes generar informes de inventario, entradas, salidas y otros movimientos.'),
(13, '¿Cómo puedo ver la bitácora de actividades?', 'Ve a la sección \"Bitácora\" en el menú para ver las actividades recientes, como el ingreso o salida de inventario y otros cambios realizados.'),
(14, '¿Qué usuarios pueden agregar productos?', 'Solo los usuarios con rol de \"Administrador\" o \"Coordinador\" tienen permisos para agregar productos al inventario.'),
(15, '¿Qué hago si olvidé mi contraseña?', 'En la página de inicio de sesión, selecciona \"Olvidé mi contraseña\" y sigue los pasos para recuperarla.'),
(16, '¿Cómo asigno roles a los usuarios?', 'Para asignar roles, ve a la sección \"Usuarios\", selecciona el usuario y elige el rol adecuado en \"Asignar rol\".'),
(17, '¿Qué roles hay en el sistema?', 'Los roles son: Administrador, Coordinador y Operador. Cada uno tiene distintos permisos dentro del sistema.'),
(18, '¿Cómo optimizo el almacenamiento?', 'En la sección de \"Optimización\", el sistema sugiere mejores ubicaciones para maximizar el espacio disponible en el almacén.'),
(19, '¿Puedo exportar los reportes?', 'Sí, los reportes se pueden exportar en formato PDF o Excel desde la sección \"Reportes\".'),
(20, '¿Cuándo se generan las alertas de espera?', 'Las alertas se generan automáticamente cuando un producto tiene tiempo excesivo en espera, según el tiempo definido por el administrador.'),
(21, '¿Cómo filtro productos por categoría?', 'En la lista de inventario, utiliza el filtro de \"Categorías\" para ver solo los productos de una categoría específica.'),
(22, '¿Se puede ver el historial de un producto?', 'Sí, selecciona un producto en \"Inventario\" y ve a la pestaña \"Historial\" para ver todas sus entradas y salidas.'),
(23, '¿Dónde veo los reportes de inventario?', 'En el menú, selecciona \"Reportes\" y elige \"Inventario\" para ver el reporte actual de todos los productos.'),
(24, '¿Cómo agrego un proveedor?', 'Ve a \"Proveedores\" en el menú y selecciona \"Agregar proveedor\". Completa el formulario y guarda la información.'),
(25, '¿Cómo actualizo la información de un proveedor?', 'Selecciona el proveedor en la lista de \"Proveedores\" y usa la opción \"Editar\" para actualizar su información.'),
(26, '¿Cómo veo los productos con bajo stock?', 'En la sección \"Inventario\", usa el filtro \"Bajo stock\" para ver los productos que están por debajo del nivel mínimo de stock establecido.');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `chatbot`
--
ALTER TABLE `chatbot`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `chatbot`
--
ALTER TABLE `chatbot`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
